/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.era7.bioinfo.uniprot.server;

/**
 *
 * @author ppareja
 */
public class CommonData {

    public static final String DATABASE_FOLDER = "/mnt/uniprotvolume/db";

}
