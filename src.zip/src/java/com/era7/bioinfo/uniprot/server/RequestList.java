/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.era7.bioinfo.uniprot.server;

/**
 *
 * @author ppareja
 */
public class RequestList {

    public static final String DOWNLOAD_PROTEIN_MULTIFASTA_REQUEST = "download_protein_multifasta";

}
